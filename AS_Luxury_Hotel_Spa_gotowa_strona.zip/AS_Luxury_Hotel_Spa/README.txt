A.S LUXURY HOTEL & SPA — PROJEKT SZKOLNY

Pliki:
- index.html — główna strona
- style.css — wygląd strony
- script.js — interakcje i formularz rezerwacyjny

Uruchomienie:
Otwórz plik index.html w przeglądarce.

Publikacja:
Folder można opublikować np. przez GitHub Pages lub Netlify.

WAŻNE:
Hotel, adres, telefon, e-mail, ceny i opinie są fikcyjne i przygotowane na potrzeby projektu szkolnego.
Zdjęcia są pobierane z Unsplash przez internetowe adresy obrazów.
